package com.lti.Controller;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.lti.Dao.BidderDao;
import com.lti.Entity.Bidder;
import com.lti.Service.BidderService;




@RestController
//@CrossOrigin
public class BidderController {
	
	@Autowired(required=true)
	private BidderService bidderService;
	
	//@CrossOrigin
	@RequestMapping(path="/bidder/add", method=RequestMethod.POST)
	public String add(@RequestBody Bidder bidder) {
		bidderService.add(bidder);
		return "Bidder record created successfully!";
		
	}
	
	@RequestMapping(path="/bidder/{id}", method=RequestMethod.POST)
	public Bidder fetch(@PathVariable("id") int id) {
		return bidderService.fetch(id);
	}

}
