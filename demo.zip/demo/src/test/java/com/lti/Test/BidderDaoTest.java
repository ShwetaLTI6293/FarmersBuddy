package com.lti.Test;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase.Replace;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.annotation.Rollback;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.transaction.annotation.Transactional;

import com.lti.Dao.BidderDao;
import com.lti.Entity.Bidder;
import com.lti.demo.DemoApplication;




@RunWith(SpringRunner.class)
@SpringBootTest(classes=DemoApplication.class)
@Rollback(false)
@AutoConfigureTestDatabase(replace=Replace.NONE)
public class BidderDaoTest {
	
	@Autowired
	private BidderDao bidderDao;
	
	
	@Transactional
	@Test
	public void add() {
		Bidder bidder = new Bidder();
		bidder.setFullName("Shweta Durkellu");
		bidder.setContactNo(8796);
		bidder.setEmailId("shweta.durkellu6@gmail.com");
		bidder.setAddress("Vishrantwadi");
		bidder.setCity("Pune");
		bidder.setState("Maharashtra");
		bidder.setPincode(41);
		bidder.setAccountNo(34);
		bidder.setIfscCode("BOM");
		bidder.setAadhar("aadhar.pdf");
		bidder.setpan("pan.pdf");
		bidder.setTraderLicence("tl.pdf");
		bidder.setPassword("shweta");
		bidder.setConfirmPassword("shweta");
		bidderDao.add(bidder);
		
		}
	public void fetchId() {
		Bidder bidder=new Bidder();
		bidder.setId(41);
		BidderDao dao=new BidderDao();
		dao.fetch(41);
		
		
	}



}
